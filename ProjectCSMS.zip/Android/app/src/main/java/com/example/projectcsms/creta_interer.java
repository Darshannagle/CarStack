package com.example.projectcsms;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class creta_interer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creta_interer);
    }
}